import torch
from torch._inductor.decomposition import decompositions as inductor_decomp

from buddy.compiler.frontend import DynamoCompiler
from buddy.compiler.ops import tosa

def func():
    x = torch.zeros((4, 4, 4))
    for i in range(4):
        y = torch.ones((4, 4))
        x[i] = y
        
    return x

dynamo_compiler = DynamoCompiler(
    primary_registry=tosa.ops_registry,
    aot_autograd_decomposition=inductor_decomp
)

graphs = dynamo_compiler.importer(func)

# print(len(graphs))
graph = graphs[0]
graph.lower_to_top_level_ir()
print(graph._imported_module)
