import torch
from bw_snn_model import vgg_bw_snn, BN2dLif

from torch._inductor.decomposition import decompositions as inductor_decomp

from buddy.compiler.frontend import DynamoCompiler
from buddy.compiler.ops import tosa

from buddy.compiler.graph import GraphDriver
from buddy.compiler.graph.transform import simply_fuse

import os

model = vgg_bw_snn(light_factor=1,T=16,leak=0.25,num_classes=11, channels_exten=True)
state_dict = torch.load('vgg_bw_snn_converted_dvsgesture_final.pth')
model.load_state_dict(state_dict=state_dict)
model.eval()

device = torch.device('cpu')
model = model.to(device)
# res = 0
# len = 0
with torch.no_grad():
    data = torch.load('data_batchSize2_timeStep16_imgSize128.pt').to(device)
    # label = torch.load('label_batchSize2_timeStep16_imgSize128.pt')
    res = model(data)
    # print(res)
    # print(label)
    
dynamo_compiler = DynamoCompiler(
    primary_registry=tosa.ops_registry,
    aot_autograd_decomposition=inductor_decomp
)

with torch.no_grad():
    graphs = dynamo_compiler.importer(model, data)
    
assert len(graphs) == 1

# graph = graphs[0]
# graph.lower_to_top_level_ir()
# print(graph._imported_module)
pattern_list = [simply_fuse]
graphs[0].fuse_ops(pattern_list)
driver = GraphDriver(graphs[0])
driver.subgraphs[0].lower_to_top_level_ir()


path_prefix = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(path_prefix, "subgraph0.mlir"), "w") as module_file:
    print(driver.subgraphs[0]._imported_module, file=module_file)
with open(os.path.join(path_prefix, "forward.mlir"), "w") as module_file:
    print(driver.construct_main_graph(True), file=module_file)
