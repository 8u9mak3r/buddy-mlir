# from os import name
# from pyexpat import model
# from turtle import forward
from typing import Mapping, Any
# from rsa import sign
import torch
import torch.nn as nn
import torch.nn.functional as F
# import math

clamp_factor = 7
Integer = True

class BN2dLif(nn.Module):
    max_act = 0
    max_act_sumT = 0
    act_shape = 0
    max_v = 0
    max_abs_v = 0
    mean_spike_rate = 0
    def __init__(self, leak, out_channels):
        super(BN2dLif, self).__init__()
        self.register_parameter('beta', nn.Parameter(torch.Tensor([0]*out_channels).reshape(-1,1,1)))
        self.register_parameter('theta', nn.Parameter(torch.Tensor([0.5]*out_channels).reshape(-1,1,1)))
        self.register_parameter('share_factor',nn.Parameter(torch.Tensor([2**5])))
        self.leak = leak

    def forward(self, input: torch.Tensor, v: torch.Tensor) -> torch.Tensor: # input [B, C, H, W]
        v = v + (input * self.share_factor)
        v = (v + self.beta)
        spike : torch.Tensor = (v > self.theta).float()
        v = (((1- spike) * v) * self.leak).int()
        # v = v.clamp(min=-1*(2**clamp_factor),max=2**clamp_factor)
        v = v.clamp_max(max=2**clamp_factor)
        v = v.clamp_min(min=-1*(2**clamp_factor))
        v = v.float()
        return spike, v

def channels_exten(x : torch.Tensor, device):
    # x.shape [T, B, C, H, W]
    # 创建一个索引张量
    T = x.shape[0]
    B = x.shape[1]
    C = x.shape[2]
    H = W = x.shape[3]
    indices = torch.arange(32).to(device)
    indices = indices.unsqueeze(-1).unsqueeze(-1).unsqueeze(-1).float()
    # 将 x 扩展为 [T, B, 32, C, H, W]
    x_expanded = x.unsqueeze(2).expand(T, B, 32, C,  H, W)
    # 比较 x_expanded 和 indices，生成 0 或 1
    result = (x_expanded > indices).float()
    # 将结果重新排列为 [T, B, C*32, H, W]
    result = result.reshape(T, B, C * 32, H, W)
    return result

cfg = [64, 64, 128, 128, 256, 256, 512]

class vgg_bw_snn(nn.Module):
    def __init__(self, in_channel = 2, num_classes=10, leak = 0.25, T =10, light_factor = 1, channels_exten = False) :
        super(vgg_bw_snn, self).__init__()
        self.T = T
        self.cfg = [i//light_factor for i in cfg]
        self.pooling = nn.MaxPool2d(kernel_size=2, stride=2)
        self.channels_exten = channels_exten
        # imageSize 128: [64, "M", 64, "M", 128, "M", 128, "M", 256, "M", 256, "M", 512, "M"]
        if channels_exten:
            self.conv0 = nn.Conv2d(in_channels=in_channel * 32, out_channels=self.cfg[0], kernel_size=3, padding=1, bias=False)
        else:
            self.conv0 = nn.Conv2d(in_channels=in_channel, out_channels=self.cfg[0], kernel_size=3, padding=1, bias=False)
        self.bn0 = BN2dLif(leak=leak,out_channels=self.cfg[0])
        self.conv1 = nn.Conv2d(in_channels=self.cfg[0], out_channels=self.cfg[1], kernel_size=3, padding=1, bias=False)
        self.bn1 = BN2dLif(leak=leak,out_channels=self.cfg[1])
        self.conv2 = nn.Conv2d(in_channels=self.cfg[1], out_channels=self.cfg[2], kernel_size=3, padding=1, bias=False)
        self.bn2 = BN2dLif(leak=leak,out_channels=self.cfg[2])
        self.conv3 = nn.Conv2d(in_channels=self.cfg[2], out_channels=self.cfg[3], kernel_size=3, padding=1, bias=False)
        self.bn3 = BN2dLif(leak=leak,out_channels=self.cfg[3])
        self.conv4 = nn.Conv2d(in_channels=self.cfg[3], out_channels=self.cfg[4], kernel_size=3, padding=1, bias=False)
        self.bn4 = BN2dLif(leak=leak,out_channels=self.cfg[4])
        self.conv5 = nn.Conv2d(in_channels=self.cfg[4], out_channels=self.cfg[5], kernel_size=3, padding=1, bias=False)
        self.bn5 = BN2dLif(leak=leak,out_channels=self.cfg[5])
        self.conv6 = nn.Conv2d(in_channels=self.cfg[5], out_channels=self.cfg[6], kernel_size=3, padding=1, bias=False)
        self.bn6 = BN2dLif(leak=leak,out_channels=self.cfg[6])
        self.fc = nn.Linear(self.cfg[6], num_classes,bias=False)
        self.nclass = num_classes

    def load_state_dict(self, state_dict: Mapping[str, Any], strict: bool = True, assign: bool = False):
        if self.channels_exten:
            if state_dict['conv0.weight'].shape == (64, 2, 3, 3):
                state_dict['conv0.weight'] = state_dict['conv0.weight'].unsqueeze(dim=1).expand(64, 32, 2, 3,3).reshape(64, 32*2, 3,3)
            else:
                assert state_dict['conv0.weight'].shape == (64, 64, 3, 3)
        return super().load_state_dict(state_dict, strict, assign)

    def forward(self, input : torch.Tensor):
        # print("Input: " + str(input.shape))
        input = input.permute(1, 0, 2, 3, 4) # [B, T, C, H, W] -> [T, B, C, H, W]
        
        # print("After Permute: " + str(input.shape))
        input = input.clamp(0,32)
        
        # print("After Clamp: " + str(input.shape))
        if self.channels_exten:
            input = channels_exten(input, device=input.device)
            
        # print("After Channels Extension: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1], self.cfg[0], input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(0,self.T):
            out[t] = self.pooling(self.conv0(input[t]))
            out[t], v = self.bn0(out[t], v)
        input = out

        # print("After Round 0: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1], self.cfg[1],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv1(input[t]))
            out[t], v = self.bn1(out[t], v)
        input = out
        
        # print("After Round 1: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1],self.cfg[2],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv2(input[t]))
            out[t], v = self.bn2(out[t], v)
        input = out

        # print("After Round 2: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1],self.cfg[3],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv3(input[t]))
            out[t], v = self.bn3(out[t], v)
        input = out
        
        # print("After Round 3: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1],self.cfg[4],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv4(input[t]))
            out[t], v = self.bn4(out[t], v)
        input = out

        # print("After Round 4: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1],self.cfg[5],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv5(input[t]))
            out[t], v = self.bn5(out[t], v)
        input = out

        # print("After Round 5: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1],self.cfg[6],input.shape[3]//2,input.shape[4]//2, device=input.device)
        v = torch.zeros_like(out[0], device=input.device)
        for t in range(self.T):
            out[t] = self.pooling(self.conv6(input[t]))
            out[t], v = self.bn6(out[t], v)
        input = out
        
        # print("After Round 6: " + str(input.shape))
        input = input.reshape(input.shape[0],input.shape[1],-1) # [T, B, C, 1, 1] -> [T, B, C]
        
        # print("After Reshape: " + str(input.shape))
        out = torch.zeros(input.shape[0],input.shape[1], self.nclass, device=input.device)
        for t in range(self.T):
            out[t] = self.fc(input[t])
            
        # print("After Linear Layer: " + str(out.shape))
        out = torch.mean(out, dim=0) # [T, B, C] -> [B, C]
        
        # print("After Mean: " + str(out.shape))

        return out
        
#only for module test
if __name__ == "__main__":
    input = torch.randint(0,33,(2, 10, 2, 128, 128)).float() # [B, T, C, H, W]
    m0 = vgg_bw_snn(channels_exten=False)
    output0: torch.Tensor = m0(input)
    m0_state = m0.state_dict()
    m1 = vgg_bw_snn(channels_exten=True)
    m1.load_state_dict(m0_state)
    output1:torch.Tensor = m1(input)
    print((output0-output1).norm())
